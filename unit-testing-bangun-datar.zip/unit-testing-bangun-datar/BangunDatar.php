<?php
abstract class BangunDatar{
    abstract public function hitungKeliling();
    abstract public function hitungLuas();
}